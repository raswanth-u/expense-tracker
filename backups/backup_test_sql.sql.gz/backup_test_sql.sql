--
-- PostgreSQL database dump
--

\restrict a4WCdnR3ATZANw0xwiaIxCxH5Os8cH3Kssog6U4FagYlc4rZB8xK5cC0WU0to1y

-- Dumped from database version 18.1
-- Dumped by pg_dump version 18.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: credit_card_payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.credit_card_payments (
    id integer NOT NULL,
    credit_card_id integer NOT NULL,
    savings_account_id integer,
    savings_transaction_id integer,
    payment_amount numeric(15,2) NOT NULL,
    outstanding_before numeric(15,2) NOT NULL,
    outstanding_after numeric(15,2) NOT NULL,
    payment_date timestamp without time zone NOT NULL,
    payment_method character varying NOT NULL,
    description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    CONSTRAINT check_positive_payment CHECK ((payment_amount > (0)::numeric))
);


ALTER TABLE public.credit_card_payments OWNER TO postgres;

--
-- Name: credit_card_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.credit_card_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.credit_card_payments_id_seq OWNER TO postgres;

--
-- Name: credit_card_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.credit_card_payments_id_seq OWNED BY public.credit_card_payments.id;


--
-- Name: credit_card_statements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.credit_card_statements (
    id integer NOT NULL,
    credit_card_id integer NOT NULL,
    statement_date timestamp without time zone NOT NULL,
    due_date timestamp without time zone NOT NULL,
    previous_balance numeric(15,2) NOT NULL,
    total_purchases numeric(15,2) NOT NULL,
    total_payments numeric(15,2) NOT NULL,
    total_fees numeric(15,2) NOT NULL,
    total_interest numeric(15,2) NOT NULL,
    closing_balance numeric(15,2) NOT NULL,
    minimum_payment_due numeric(15,2) NOT NULL,
    is_paid boolean NOT NULL,
    paid_date timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.credit_card_statements OWNER TO postgres;

--
-- Name: credit_card_statements_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.credit_card_statements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.credit_card_statements_id_seq OWNER TO postgres;

--
-- Name: credit_card_statements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.credit_card_statements_id_seq OWNED BY public.credit_card_statements.id;


--
-- Name: credit_card_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.credit_card_transactions (
    id integer NOT NULL,
    credit_card_id integer NOT NULL,
    transaction_type character varying NOT NULL,
    amount numeric(15,2) NOT NULL,
    outstanding_after numeric(15,2) NOT NULL,
    transaction_date timestamp without time zone NOT NULL,
    description character varying,
    merchant_name character varying,
    tags character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    CONSTRAINT check_nonzero_amount CHECK ((amount <> (0)::numeric))
);


ALTER TABLE public.credit_card_transactions OWNER TO postgres;

--
-- Name: credit_card_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.credit_card_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.credit_card_transactions_id_seq OWNER TO postgres;

--
-- Name: credit_card_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.credit_card_transactions_id_seq OWNED BY public.credit_card_transactions.id;


--
-- Name: credit_cards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.credit_cards (
    id integer NOT NULL,
    user_id integer NOT NULL,
    card_name character varying NOT NULL,
    card_number character varying NOT NULL,
    card_type character varying NOT NULL,
    credit_limit numeric(15,2) NOT NULL,
    available_credit numeric(15,2) NOT NULL,
    outstanding_balance numeric(15,2) NOT NULL,
    billing_cycle_day integer NOT NULL,
    payment_due_day integer NOT NULL,
    interest_rate numeric(5,2) NOT NULL,
    minimum_payment_percentage numeric(5,2) NOT NULL,
    expiry_date timestamp without time zone,
    is_active boolean NOT NULL,
    tags character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    CONSTRAINT check_positive_credit_limit CHECK ((credit_limit > (0)::numeric)),
    CONSTRAINT check_positive_outstanding CHECK ((outstanding_balance >= (0)::numeric)),
    CONSTRAINT check_valid_available_credit CHECK (((available_credit >= (0)::numeric) AND (available_credit <= credit_limit)))
);


ALTER TABLE public.credit_cards OWNER TO postgres;

--
-- Name: credit_cards_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.credit_cards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.credit_cards_id_seq OWNER TO postgres;

--
-- Name: credit_cards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.credit_cards_id_seq OWNED BY public.credit_cards.id;


--
-- Name: debit_cards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.debit_cards (
    id integer NOT NULL,
    user_id integer NOT NULL,
    savings_account_id integer NOT NULL,
    card_name character varying NOT NULL,
    card_number character varying NOT NULL,
    card_type character varying NOT NULL,
    expiry_date timestamp without time zone,
    is_active boolean NOT NULL,
    tags character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.debit_cards OWNER TO postgres;

--
-- Name: debit_cards_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.debit_cards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.debit_cards_id_seq OWNER TO postgres;

--
-- Name: debit_cards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.debit_cards_id_seq OWNED BY public.debit_cards.id;


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.expenses (
    id integer NOT NULL,
    user_id integer NOT NULL,
    debit_card_id integer,
    credit_card_id integer,
    credit_card_transaction_id integer,
    savings_transaction_id integer,
    category character varying NOT NULL,
    amount numeric(15,2) NOT NULL,
    payment_method character varying NOT NULL,
    expense_date timestamp without time zone NOT NULL,
    description character varying,
    merchant_name character varying,
    tags character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    savings_account_id integer,
    CONSTRAINT check_positive_expense_amount CHECK ((amount > (0)::numeric))
);


ALTER TABLE public.expenses OWNER TO postgres;

--
-- Name: expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.expenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.expenses_id_seq OWNER TO postgres;

--
-- Name: expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.expenses_id_seq OWNED BY public.expenses.id;


--
-- Name: savings_accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.savings_accounts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    account_name character varying NOT NULL,
    bank_name character varying NOT NULL,
    account_number character varying NOT NULL,
    account_type character varying NOT NULL,
    minimum_balance numeric(15,2) NOT NULL,
    current_balance numeric(15,2) NOT NULL,
    interest_rate numeric(5,2) NOT NULL,
    tags character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    CONSTRAINT check_positive_balance CHECK ((current_balance >= (0)::numeric)),
    CONSTRAINT check_positive_min_balance CHECK ((minimum_balance >= (0)::numeric))
);


ALTER TABLE public.savings_accounts OWNER TO postgres;

--
-- Name: savings_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.savings_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.savings_accounts_id_seq OWNER TO postgres;

--
-- Name: savings_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.savings_accounts_id_seq OWNED BY public.savings_accounts.id;


--
-- Name: savings_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.savings_transactions (
    id integer NOT NULL,
    savings_account_id integer NOT NULL,
    transaction_type character varying NOT NULL,
    amount numeric(15,2) NOT NULL,
    balance_after numeric(15,2) NOT NULL,
    transaction_date timestamp without time zone NOT NULL,
    description character varying,
    tags character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    CONSTRAINT check_positive_amount CHECK ((amount > (0)::numeric))
);


ALTER TABLE public.savings_transactions OWNER TO postgres;

--
-- Name: savings_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.savings_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.savings_transactions_id_seq OWNER TO postgres;

--
-- Name: savings_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.savings_transactions_id_seq OWNED BY public.savings_transactions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name character varying NOT NULL,
    email character varying NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    is_active boolean NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: credit_card_payments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credit_card_payments ALTER COLUMN id SET DEFAULT nextval('public.credit_card_payments_id_seq'::regclass);


--
-- Name: credit_card_statements id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credit_card_statements ALTER COLUMN id SET DEFAULT nextval('public.credit_card_statements_id_seq'::regclass);


--
-- Name: credit_card_transactions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credit_card_transactions ALTER COLUMN id SET DEFAULT nextval('public.credit_card_transactions_id_seq'::regclass);


--
-- Name: credit_cards id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credit_cards ALTER COLUMN id SET DEFAULT nextval('public.credit_cards_id_seq'::regclass);


--
-- Name: debit_cards id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debit_cards ALTER COLUMN id SET DEFAULT nextval('public.debit_cards_id_seq'::regclass);


--
-- Name: expenses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.expenses ALTER COLUMN id SET DEFAULT nextval('public.expenses_id_seq'::regclass);


--
-- Name: savings_accounts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.savings_accounts ALTER COLUMN id SET DEFAULT nextval('public.savings_accounts_id_seq'::regclass);


--
-- Name: savings_transactions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.savings_transactions ALTER COLUMN id SET DEFAULT nextval('public.savings_transactions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
3c48ced5f97f
\.


--
-- Data for Name: credit_card_payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.credit_card_payments (id, credit_card_id, savings_account_id, savings_transaction_id, payment_amount, outstanding_before, outstanding_after, payment_date, payment_method, description, created_at, updated_at) FROM stdin;
1	2	2	3	1000.00	10000.00	9000.00	2026-01-16 15:13:30.724935	net_banking	credit payment	2026-01-16 15:13:30.724935	2026-01-16 15:13:30.745273
\.


--
-- Data for Name: credit_card_statements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.credit_card_statements (id, credit_card_id, statement_date, due_date, previous_balance, total_purchases, total_payments, total_fees, total_interest, closing_balance, minimum_payment_due, is_paid, paid_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: credit_card_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.credit_card_transactions (id, credit_card_id, transaction_type, amount, outstanding_after, transaction_date, description, merchant_name, tags, created_at, updated_at) FROM stdin;
1	2	purchase	3000.00	3000.00	2026-01-16 15:09:58.822801	\N	amazon	eq	2026-01-16 15:09:58.822801	2026-01-16 15:09:58.822801
2	2	purchase	7000.00	10000.00	2026-01-16 15:10:34.725085	abc	mop	w1	2026-01-16 15:10:34.725085	2026-01-16 15:10:34.725085
3	1	purchase	50.00	50.00	2026-01-17 22:33:10.660421	transportation - re	am	q	2026-01-17 22:33:10.660421	2026-01-17 22:33:10.660421
\.


--
-- Data for Name: credit_cards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.credit_cards (id, user_id, card_name, card_number, card_type, credit_limit, available_credit, outstanding_balance, billing_cycle_day, payment_due_day, interest_rate, minimum_payment_percentage, expiry_date, is_active, tags, created_at, updated_at) FROM stdin;
2	4	bam	1234567812344432	mastercard	400000.00	291000.00	9000.00	12	20	3.00	2.00	2026-12-20 00:00:00	t	\N	2026-01-16 14:34:01.295392	2026-01-16 15:13:30.715492
1	4	Rupay	1990887990880099	visa	500000.00	499950.00	50.00	12	29	6.00	5.00	2026-12-30 00:00:00	t	RA	2026-01-16 00:37:28.014481	2026-01-17 22:33:10.658471
\.


--
-- Data for Name: debit_cards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.debit_cards (id, user_id, savings_account_id, card_name, card_number, card_type, expiry_date, is_active, tags, created_at, updated_at) FROM stdin;
3	4	2	prim	1010998900002345	rupay	\N	t	\N	2026-01-15 19:43:49.020478	2026-01-15 19:43:49.020478
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.expenses (id, user_id, debit_card_id, credit_card_id, credit_card_transaction_id, savings_transaction_id, category, amount, payment_method, expense_date, description, merchant_name, tags, created_at, updated_at, savings_account_id) FROM stdin;
1	4	3	\N	\N	4	food	300.00	debit_card	2026-12-10 00:00:00	M dress	amazon	M R A	2026-01-17 22:32:17.67786	2026-01-17 22:32:17.685643	\N
2	4	\N	1	3	\N	transportation	50.00	credit_card	2026-01-17 22:33:10.651421	re	am	q	2026-01-17 22:33:10.664425	2026-01-17 22:33:10.666366	\N
3	4	\N	\N	\N	\N	entertainment	200.00	upi	2026-06-04 00:00:00	Aunty	map	lsk	2026-01-17 22:48:40.288862	2026-01-17 23:04:33.87381	2
\.


--
-- Data for Name: savings_accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.savings_accounts (id, user_id, account_name, bank_name, account_number, account_type, minimum_balance, current_balance, interest_rate, tags, created_at, updated_at) FROM stdin;
2	4	Sav	hdfc	100009899	abc	2000.00	1500.00	2.00	ras	2026-01-14 21:03:00.320347	2026-01-17 22:48:40.282206
\.


--
-- Data for Name: savings_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.savings_transactions (id, savings_account_id, transaction_type, amount, balance_after, transaction_date, description, tags, created_at, updated_at) FROM stdin;
1	2	deposit	3000.00	3500.00	2026-12-09 00:00:00	\N	\N	2026-01-14 21:32:02.857966	2026-01-14 21:32:02.857966
2	2	withdrawal	500.00	3000.00	2026-01-14 21:48:07.885924	\N	\N	2026-01-14 21:48:07.906408	2026-01-14 21:48:07.906408
3	2	credit_card_payment	1000.00	2000.00	2026-01-16 15:13:30.718014	Credit card payment: bam	\N	2026-01-16 15:13:30.718014	2026-01-16 15:13:30.718014
4	2	debit_card	300.00	1700.00	2026-01-17 22:32:17.668861	Expense: food - M dress	\N	2026-01-17 22:32:17.668861	2026-01-17 22:32:17.668861
5	2	upi	200.00	1500.00	2026-06-04 00:00:00	Expense: entertainment - N/A	\N	2026-01-17 22:48:40.284922	2026-01-17 22:48:40.284922
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, name, email, created_at, updated_at, is_active) FROM stdin;
2	string	user@example.com	2026-01-13 19:04:22.4912	2026-01-13 19:04:22.4912	t
4	siva	ram@bm.com	2026-01-14 18:50:45.544958	2026-01-14 18:51:47.116533	t
\.


--
-- Name: credit_card_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.credit_card_payments_id_seq', 1, true);


--
-- Name: credit_card_statements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.credit_card_statements_id_seq', 1, false);


--
-- Name: credit_card_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.credit_card_transactions_id_seq', 3, true);


--
-- Name: credit_cards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.credit_cards_id_seq', 2, true);


--
-- Name: debit_cards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.debit_cards_id_seq', 3, true);


--
-- Name: expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.expenses_id_seq', 3, true);


--
-- Name: savings_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.savings_accounts_id_seq', 2, true);


--
-- Name: savings_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.savings_transactions_id_seq', 5, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 4, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: credit_card_payments credit_card_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credit_card_payments
    ADD CONSTRAINT credit_card_payments_pkey PRIMARY KEY (id);


--
-- Name: credit_card_statements credit_card_statements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credit_card_statements
    ADD CONSTRAINT credit_card_statements_pkey PRIMARY KEY (id);


--
-- Name: credit_card_transactions credit_card_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credit_card_transactions
    ADD CONSTRAINT credit_card_transactions_pkey PRIMARY KEY (id);


--
-- Name: credit_cards credit_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credit_cards
    ADD CONSTRAINT credit_cards_pkey PRIMARY KEY (id);


--
-- Name: debit_cards debit_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debit_cards
    ADD CONSTRAINT debit_cards_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: savings_accounts savings_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.savings_accounts
    ADD CONSTRAINT savings_accounts_pkey PRIMARY KEY (id);


--
-- Name: savings_transactions savings_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.savings_transactions
    ADD CONSTRAINT savings_transactions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_credit_card_payments_credit_card_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_credit_card_payments_credit_card_id ON public.credit_card_payments USING btree (credit_card_id);


--
-- Name: ix_credit_card_payments_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_credit_card_payments_id ON public.credit_card_payments USING btree (id);


--
-- Name: ix_credit_card_payments_payment_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_credit_card_payments_payment_date ON public.credit_card_payments USING btree (payment_date);


--
-- Name: ix_credit_card_payments_savings_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_credit_card_payments_savings_account_id ON public.credit_card_payments USING btree (savings_account_id);


--
-- Name: ix_credit_card_payments_savings_transaction_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_credit_card_payments_savings_transaction_id ON public.credit_card_payments USING btree (savings_transaction_id);


--
-- Name: ix_credit_card_statements_credit_card_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_credit_card_statements_credit_card_id ON public.credit_card_statements USING btree (credit_card_id);


--
-- Name: ix_credit_card_statements_due_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_credit_card_statements_due_date ON public.credit_card_statements USING btree (due_date);


--
-- Name: ix_credit_card_statements_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_credit_card_statements_id ON public.credit_card_statements USING btree (id);


--
-- Name: ix_credit_card_statements_statement_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_credit_card_statements_statement_date ON public.credit_card_statements USING btree (statement_date);


--
-- Name: ix_credit_card_transactions_credit_card_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_credit_card_transactions_credit_card_id ON public.credit_card_transactions USING btree (credit_card_id);


--
-- Name: ix_credit_card_transactions_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_credit_card_transactions_id ON public.credit_card_transactions USING btree (id);


--
-- Name: ix_credit_card_transactions_transaction_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_credit_card_transactions_transaction_date ON public.credit_card_transactions USING btree (transaction_date);


--
-- Name: ix_credit_cards_card_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_credit_cards_card_number ON public.credit_cards USING btree (card_number);


--
-- Name: ix_credit_cards_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_credit_cards_id ON public.credit_cards USING btree (id);


--
-- Name: ix_credit_cards_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_credit_cards_user_id ON public.credit_cards USING btree (user_id);


--
-- Name: ix_debit_cards_card_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_debit_cards_card_number ON public.debit_cards USING btree (card_number);


--
-- Name: ix_debit_cards_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_debit_cards_id ON public.debit_cards USING btree (id);


--
-- Name: ix_debit_cards_savings_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_debit_cards_savings_account_id ON public.debit_cards USING btree (savings_account_id);


--
-- Name: ix_debit_cards_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_debit_cards_user_id ON public.debit_cards USING btree (user_id);


--
-- Name: ix_expenses_credit_card_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_expenses_credit_card_id ON public.expenses USING btree (credit_card_id);


--
-- Name: ix_expenses_credit_card_transaction_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_expenses_credit_card_transaction_id ON public.expenses USING btree (credit_card_transaction_id);


--
-- Name: ix_expenses_debit_card_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_expenses_debit_card_id ON public.expenses USING btree (debit_card_id);


--
-- Name: ix_expenses_expense_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_expenses_expense_date ON public.expenses USING btree (expense_date);


--
-- Name: ix_expenses_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_expenses_id ON public.expenses USING btree (id);


--
-- Name: ix_expenses_savings_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_expenses_savings_account_id ON public.expenses USING btree (savings_account_id);


--
-- Name: ix_expenses_savings_transaction_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_expenses_savings_transaction_id ON public.expenses USING btree (savings_transaction_id);


--
-- Name: ix_expenses_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_expenses_user_id ON public.expenses USING btree (user_id);


--
-- Name: ix_savings_accounts_account_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_savings_accounts_account_number ON public.savings_accounts USING btree (account_number);


--
-- Name: ix_savings_accounts_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_savings_accounts_id ON public.savings_accounts USING btree (id);


--
-- Name: ix_savings_accounts_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_savings_accounts_user_id ON public.savings_accounts USING btree (user_id);


--
-- Name: ix_savings_transactions_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_savings_transactions_id ON public.savings_transactions USING btree (id);


--
-- Name: ix_savings_transactions_savings_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_savings_transactions_savings_account_id ON public.savings_transactions USING btree (savings_account_id);


--
-- Name: ix_savings_transactions_transaction_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_savings_transactions_transaction_date ON public.savings_transactions USING btree (transaction_date);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_name ON public.users USING btree (name);


--
-- Name: credit_card_payments credit_card_payments_credit_card_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credit_card_payments
    ADD CONSTRAINT credit_card_payments_credit_card_id_fkey FOREIGN KEY (credit_card_id) REFERENCES public.credit_cards(id) ON DELETE CASCADE;


--
-- Name: credit_card_payments credit_card_payments_savings_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credit_card_payments
    ADD CONSTRAINT credit_card_payments_savings_account_id_fkey FOREIGN KEY (savings_account_id) REFERENCES public.savings_accounts(id) ON DELETE SET NULL;


--
-- Name: credit_card_payments credit_card_payments_savings_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credit_card_payments
    ADD CONSTRAINT credit_card_payments_savings_transaction_id_fkey FOREIGN KEY (savings_transaction_id) REFERENCES public.savings_transactions(id) ON DELETE SET NULL;


--
-- Name: credit_card_statements credit_card_statements_credit_card_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credit_card_statements
    ADD CONSTRAINT credit_card_statements_credit_card_id_fkey FOREIGN KEY (credit_card_id) REFERENCES public.credit_cards(id) ON DELETE CASCADE;


--
-- Name: credit_card_transactions credit_card_transactions_credit_card_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credit_card_transactions
    ADD CONSTRAINT credit_card_transactions_credit_card_id_fkey FOREIGN KEY (credit_card_id) REFERENCES public.credit_cards(id) ON DELETE CASCADE;


--
-- Name: credit_cards credit_cards_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credit_cards
    ADD CONSTRAINT credit_cards_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: debit_cards debit_cards_savings_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debit_cards
    ADD CONSTRAINT debit_cards_savings_account_id_fkey FOREIGN KEY (savings_account_id) REFERENCES public.savings_accounts(id) ON DELETE CASCADE;


--
-- Name: debit_cards debit_cards_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.debit_cards
    ADD CONSTRAINT debit_cards_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: expenses expenses_credit_card_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_credit_card_id_fkey FOREIGN KEY (credit_card_id) REFERENCES public.credit_cards(id) ON DELETE SET NULL;


--
-- Name: expenses expenses_credit_card_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_credit_card_transaction_id_fkey FOREIGN KEY (credit_card_transaction_id) REFERENCES public.credit_card_transactions(id) ON DELETE SET NULL;


--
-- Name: expenses expenses_debit_card_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_debit_card_id_fkey FOREIGN KEY (debit_card_id) REFERENCES public.debit_cards(id) ON DELETE SET NULL;


--
-- Name: expenses expenses_savings_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_savings_account_id_fkey FOREIGN KEY (savings_account_id) REFERENCES public.savings_accounts(id) ON DELETE SET NULL;


--
-- Name: expenses expenses_savings_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_savings_transaction_id_fkey FOREIGN KEY (savings_transaction_id) REFERENCES public.savings_transactions(id) ON DELETE SET NULL;


--
-- Name: expenses expenses_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: savings_accounts savings_accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.savings_accounts
    ADD CONSTRAINT savings_accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: savings_transactions savings_transactions_savings_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.savings_transactions
    ADD CONSTRAINT savings_transactions_savings_account_id_fkey FOREIGN KEY (savings_account_id) REFERENCES public.savings_accounts(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict a4WCdnR3ATZANw0xwiaIxCxH5Os8cH3Kssog6U4FagYlc4rZB8xK5cC0WU0to1y

